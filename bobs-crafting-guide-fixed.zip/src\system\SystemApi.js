/**
* Main System API Singleton
* Replaces the global beaversSystemInterface from the original module architecture
*/
import { Dnd5eSystem } from './Dnd5eSystem.js';
/**
* Bob's Crafting System - Main API singleton
*/
export class BobsCraftingSystem {
	constructor() {
		this.dnd5e = new Dnd5eSystem();
		this.testClasses = new Map();
	}
	static getInstance() {
		if (!this.instance) {
			this.instance = new BobsCraftingSystem();
		}
		return this.instance;
	}
	/**
	* Register a test class for use in recipes
	* @param name Test class name (e.g., "SkillTest")
	* @param testClass Test class constructor
	*/
	registerTest(name, testClass) {
		this.testClasses.set(name, testClass);
	}
	/**
	* Get a registered test class
	* @param name Test class name
	* @returns Test class or undefined
	*/
	getTest(name) {
		return this.testClasses.get(name);
	}
	/**
	* Check if a test class is registered
	* @param name Test class name
	* @returns True if registered
	*/
	hasTest(name) {
		return this.testClasses.has(name);
	}
	/**
	* Get all registered test class names
	* @returns Array of test class names
	*/
	getTestNames() {
		return Array.from(this.testClasses.keys());
	}
	/**
	* Initialize the system (called on ready hook)
	*/
	async initialize() {
		console.log("Bob's Crafting System | System API initialized");
	}
}
