/**
* DnD 5e System Implementation
* Provides all DnD 5e-specific functionality
* Replaces bsa-dnd5e module
*/
import { Component } from './Component.js';
/**
* DnD 5e system implementation
*/
export class Dnd5eSystem {
	constructor() {
		this.configLootItemType = "loot";
		this.configCanRollAbility = true;
		this.dnd5eVersion = game.system?.version || "5.0.0";
	}
	get majorVersion() {
		return parseInt(this.dnd5eVersion.split('.')[0]);
	}
	get minorVersion() {
		return parseInt(this.dnd5eVersion.split('.')[1]);
	}
	get patchVersion() {
		return parseInt(this.dnd5eVersion.split('.')[2] || "0");
	}
	/**
	* Get DnD 5e skills configuration
	*/
	get configSkills() {
		const skills = [];
		// @ts-ignore
		const dnd5eSkills = CONFIG.DND5E?.skills || {};
		for (const [id, skill] of Object.entries(dnd5eSkills)) {
			skills.push({
				id: id,
				// @ts-ignore
				label: skill.label || id,
				// @ts-ignore
				ability: skill.ability || ""
			});
		}
		return skills;
	}
	/**
	* Get DnD 5e abilities configuration
	*/
	get configAbilities() {
		const abilities = [];
		// @ts-ignore
		const dnd5eAbilities = CONFIG.DND5E?.abilities || {};
		for (const [id, ability] of Object.entries(dnd5eAbilities)) {
			abilities.push({
				id: id,
				// @ts-ignore
				label: ability.label || id
			});
		}
		return abilities;
	}
	/**
	* Get DnD 5e currencies configuration
	* Sorted from highest to lowest value
	*/
	get configCurrencies() {
		return [
			{
				id: "pp",
				label: "DND5E.CurrencyPP",
				abbreviation: "DND5E.CurrencyAbbrPP",
				conversion: 10,
				component: undefined
			},
			{
				id: "gp",
				label: "DND5E.CurrencyGP",
				abbreviation: "DND5E.CurrencyAbbrGP",
				conversion: 1,
				component: undefined
			},
			{
				id: "ep",
				label: "DND5E.CurrencyEP",
				abbreviation: "DND5E.CurrencyAbbrEP",
				conversion: 0.5,
				component: undefined
			},
			{
				id: "sp",
				label: "DND5E.CurrencySP",
				abbreviation: "DND5E.CurrencyAbbrSP",
				conversion: 0.1,
				component: undefined
			},
			{
				id: "cp",
				label: "DND5E.CurrencyCP",
				abbreviation: "DND5E.CurrencyAbbrCP",
				conversion: 0.01,
				component: undefined
			}
		];
	}
	/**
	* Roll a skill check for an actor
	* @param actor The actor rolling
	* @param skillId The skill ID
	* @param options Roll options
	* @returns The roll result
	*/
	async actorRollSkill(actor, skillId, options = {}) {
		try {
			// DnD 5e 5.x+ API
			// @ts-ignore
			return await actor.rollSkill(skillId, options);
		}
		catch (e) {
			console.error("Error rolling skill:", e);
			throw e;
		}
	}
	/**
	* Roll an ability check for an actor
	* @param actor The actor rolling
	* @param abilityId The ability ID
	* @param options Roll options
	* @returns The roll result
	*/
	async actorRollAbility(actor, abilityId, options = {}) {
		try {
			// DnD 5e 5.x+ API
			// @ts-ignore
			return await actor.rollAbilityTest(abilityId, options);
		}
		catch (e) {
			console.error("Error rolling ability:", e);
			throw e;
		}
	}
	/**
	* Roll a tool check for an actor
	* @param actor The actor rolling
	* @param item The tool item
	* @param options Roll options
	* @returns The roll result
	*/
	async actorRollTool(actor, item, options = {}) {
		try {
			// DnD 5e tool check
			// @ts-ignore
			return await item.rollToolCheck(options);
		}
		catch (e) {
			console.error("Error rolling tool:", e);
			throw e;
		}
	}
	/**
	* Add or remove components from an actor's inventory
	* @param actor The actor
	* @param components List of components (negative quantity = remove)
	* @returns Changes made (for rollback)
	*/
	async actorComponentListAdd(actor, components) {
		const toCreate = [];
		const toUpdate = [];
		const toDelete = [];
		for (const component of components) {
			if (component.type === "Currency") {
				// Currency handled separately
				continue;
			}
			if (component.type === "RollTable") {
				// Roll tables need special handling
				const table = await fromUuid(component.uuid);
				if (table && table instanceof RollTable) {
					// @ts-ignore
					const results = await table.drawMany(component.quantity, { displayChat: false });
					for (const result of results.results) {
						if (result.type === 0) { // Text result
							continue;
						}
						// Get the item from the result
						const resultDoc = await fromUuid(result.documentCollection + "." + result.documentId);
						if (resultDoc) {
							const itemComponent = Component.fromEntity(resultDoc);
							itemComponent.quantity = 1;
							components.push(itemComponent);
						}
					}
				}
				continue;
			}
			if (component.quantity > 0) {
				// Adding items
				const existing = this.findMatchingItem(actor, component);
				if (existing) {
					toUpdate.push({
						_id: existing.id,
						"system.quantity": existing.system.quantity + component.quantity
					});
				}
				else {
					const itemData = await this.componentToItemData(component);
					toCreate.push(itemData);
				}
			}
			else if (component.quantity < 0) {
				// Removing items
				const existing = this.findMatchingItem(actor, component);
				if (existing) {
					const newQuantity = existing.system.quantity + component.quantity; // component.quantity is negative
					if (newQuantity <= 0) {
						toDelete.push(existing.id);
					}
					else {
						toUpdate.push({
							_id: existing.id,
							"system.quantity": newQuantity
						});
					}
				}
				else {
					throw new Error(`Cannot remove ${component.name}: not found in inventory`);
				}
			}
		}
		// Execute operations
		if (toCreate.length > 0) {
			await actor.createEmbeddedDocuments("Item", toCreate);
		}
		if (toUpdate.length > 0) {
			await actor.updateEmbeddedDocuments("Item", toUpdate);
		}
		if (toDelete.length > 0) {
			await actor.deleteEmbeddedDocuments("Item", toDelete);
		}
		return {
			create: toCreate,
			update: toUpdate,
			delete: toDelete.map(id => ({ _id: id }))
		};
	}
	/**
	* Find matching items in actor's inventory
	* @param items Actor's item collection
	* @param component Component to find
	* @returns Quantity and matching items
	*/
	itemListComponentFind(items, component) {
		let quantity = 0;
		const matchingItems = [];
		for (const item of items) {
			if (this.isSameItem(item, component)) {
				quantity += item.system?.quantity || 1;
				matchingItems.push(item);
			}
		}
		return { quantity, items: matchingItems };
	}
	/**
	* Check if an item matches a component
	* @param item The Foundry item
	* @param component The component to match
	* @returns True if they match
	*/
	isSameItem(item, component) {
		// Debug logging
		console.log("Comparing item:", {
			name: item.name,
			type: item.type,
			uuid: item.uuid
		}, "with component:", {
			name: component.name,
			type: component.type,
			uuid: component.uuid
		});
		// If UUIDs match, they're the same item
		if (component.uuid && item.uuid && component.uuid === item.uuid) {
			console.log("  -> Match by UUID!");
			return true;
		}
		// Fallback to name+type comparison (works even if UUIDs don't match)
		const nameMatch = item.name === component.name;
		const typeMatch = item.type === component.type;
		const finalMatch = nameMatch && typeMatch;
		console.log("  -> Name match:", nameMatch, "Type match:", typeMatch, "Final:", finalMatch);
		return finalMatch;
	}
	/**
	* Find a matching item in actor's inventory
	* @param actor The actor
	* @param component The component to find
	* @returns The matching item or undefined
	*/
	findMatchingItem(actor, component) {
		return actor.items.find(item => this.isSameItem(item, component));
	}
	/**
	* Convert a component to Foundry item data
	* @param component The component
	* @returns Item data ready for creation
	*/
	async componentToItemData(component) {
		// If we have a UUID, fetch the source item
		if (component.uuid) {
			const sourceItem = await fromUuid(component.uuid);
			if (sourceItem) {
				const itemData = sourceItem.toObject();
				itemData.system.quantity = component.quantity;
				// Apply flags
				if (component.flags) {
					itemData.flags = foundry.utils.mergeObject(itemData.flags || {}, component.flags);
				}
				return itemData;
			}
		}
		// Fallback: create basic item data
		return {
			name: component.name,
			type: component.type || "loot",
			img: component.img,
			system: {
				quantity: component.quantity
			},
			flags: component.flags || {}
		};
	}
}
