/**
 * Increment Step Test Implementation
 * Auto-success test for simple progression (no roll required)
 */
/**
 * Increment Step - automatic success without rolling
 * Used for time-based or simple progression
 */
export class IncrementStep {
    static create(data) {
        return new IncrementStepCustomized(data);
    }
    // For compatibility with the Test interface
    create(data) {
        return IncrementStep.create(data);
    }
}
class IncrementStepCustomized {
    constructor(data) {
        this.data = {
            value: data.value || 1
        };
    }
    render() {
        if (this.data.value === 1) {
            return "Progress";
        }
        return `Progress +${this.data.value}`;
    }
    async action(initiatorData) {
        // Automatic success
        return {
            success: this.data.value || 1,
            fail: 0
        };
    }
}
