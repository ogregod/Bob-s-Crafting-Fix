/**
 * Test System Interfaces
 * Base interfaces for the test/check system used in crafting
 */
export {};
